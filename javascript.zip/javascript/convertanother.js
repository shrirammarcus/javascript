var continent = ["south america","asia","australia","europe","north america","africa",];
var asia=["india","indonesia","japan","saudi arabia","republic of korea","china"];
var australia=["australia"];
var europe=["france","germany","italy","russia","turkey"];
var sa=["argentina","brazil"];
var na=["canada","mexico","usa"];
var africa=["south africa"];

var fs = require('fs');
var data = fs.readFileSync("Table.csv");
var newRecord=[];
var stringData=data.toString();
var arrayOne= stringData.split('\n');
var header=arrayOne[0].split(',');
var noOfRow=arrayOne.length;
var noOfCol=header.length;

var jArray=[];
var i=j=k=pop_index=gdp_index=0;
var obj={};
var jArray=[];
var popu=[];

var headerText=[];
var valueText=[];
var gdp=[];

for(i=0;i<noOfCol;i++)
{
 if(header[i]=="Population (Millions) 2015")
     pop_index=i;
 if(header[i]=="GDP Billions (USD) 2015")
     gdp_index=i;
     if(i<6)
     {
       popu[i]=0.0;
       gdp[i]=0.0;
     }
}

for(var j=1;j<noOfRow;j++)
{
 newRecord=arrayOne[j].split(',');
 if( sa.indexOf(newRecord[0].toLowerCase()) >-1 )
       pop_sum(0);
 if( asia.indexOf(newRecord[0].toLowerCase()) >-1 )
     pop_sum(1);
 if( australia.indexOf(newRecord[0].toLowerCase()) >-1 )
   pop_sum(2);
 if( europe.indexOf(newRecord[0].toLowerCase()) >-1 )
    pop_sum(3);
 if( na.indexOf(newRecord[0].toLowerCase()) >-1 )
       pop_sum(4);
 if( africa.indexOf(newRecord[0].toLowerCase()) >-1 )
     pop_sum(5);
}

function pop_sum(i){
   popu[i] = popu[i] + parseFloat(newRecord[pop_index]);
   gdp[i] = gdp[i] + parseFloat(newRecord[gdp_index]);
}

for (k = 0; k<=5; k++) {
   var obj={};
 headerText1 = "continent";
 valueText1= continent[k];

 headerText2 = "population";
 valueText2 = popu[k];

 headerText3 = "GDP";
 valueText3 = gdp[k];

 obj[headerText1] = valueText1;
 obj[headerText2] = valueText2;
 obj[headerText3] = valueText3;

 jArray.push(obj);

}
console.log(jArray);
fs.writeFile( "continent.json", JSON.stringify( jArray ), "utf8", (err) => {
if (err) throw err;
console.log('Saved as JSON!');
});

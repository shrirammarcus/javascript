var fs = require('fs');
var data = fs.readFileSync("Table.csv");
var newRecord=[];
var stringData=data.toString();
var arrayOne= stringData.split('\n');
var header=arrayOne[0].split(',');
var noOfRow=arrayOne.length;
var noOfCol=header.length;
var col= 2;

g20();
cgp();

function g20()
{
          var continent = ["south america","asia","australia","europe","north america","africa",];
          var asia=["india","indonesia","japan","saudi arabia","republic of korea","china"];
          var australia=["australia"];
          var europe=["france","germany","italy","russia","turkey"];
          var sa=["argentina","brazil"];
          var na=["canada","mexico","usa"];
          var africa=["south africa"];

          var jArray=[];
          var i=j=k=pop_index=gdp_index=0;
          var obj={};
          var jArray=[];
          var popu=[];

          var headerText=[];
          var valueText=[];
          var gdp=[];

          for(i=0;i<noOfRow;i++)
          {
            if(header[i]=="Population (Millions) 2015")
                pop_index=i;
            if(header[i]=="GDP Billions (USD) 2015")
                gdp_index=i;
                if(i<6)
                {
                  popu[i]=0.0;
                  gdp[i]=0.0;
                }
          }

          for(var j=1;j<noOfRow;j++)
          {
            newRecord=arrayOne[j].split(',');
            if( sa.indexOf(newRecord[0].toLowerCase()) >-1 )
                  pop_sum(0);
            if( asia.indexOf(newRecord[0].toLowerCase()) >-1 )
                pop_sum(1);
            if( australia.indexOf(newRecord[0].toLowerCase()) >-1 )
              pop_sum(2);
            if( europe.indexOf(newRecord[0].toLowerCase()) >-1 )
               pop_sum(3);
            if( na.indexOf(newRecord[0].toLowerCase()) >-1 )
                  pop_sum(4);
            if( africa.indexOf(newRecord[0].toLowerCase()) >-1 )
                pop_sum(5);
          }

          function pop_sum(i){
              popu[i] = popu[i] + parseFloat(newRecord[pop_index]);
              gdp[i] = gdp[i] + parseFloat(newRecord[gdp_index]);
          }

          for (k = 0; k<=5; k++) {

            var obj={};
            hText1 = "continent";
            vText1= continent[k];

            hText2 = "population";
            vText2 = popu[k];

            hText3 = "GDP";
            vText3 = gdp[k];

            obj[hText1] = vText1;
            obj[hText2] = vText2;
            obj[hText3] = vText3;

            jArray.push(obj);

          }
          console.log(jArray);
          fs.writeFile( "continent.json", JSON.stringify( jArray ), "utf8", (err) => {
          if (err) throw err;
          console.log('Saved as G20_JSON!');
          });

}

function cgp(){
                var index1=index2=index3=0;

                for(i=0;i<noOfCol;i++)
                {
                  if(header[i]=="Population (Millions) 2013")
                      index1=i;
                  if(header[i]=="GDP Billions (USD) 2013")
                     index2=i;
                 if(header[i]=="Gross domestic product based on Purchasing-Power-Parity (PPP) valuation of Country GDP in Billions (Current International Dollar) 2013")
                     index3=i;
               }


                csvtojson(index1,"cbyp.json");
                csvtojson(index2,"gdp.json");
                csvtojson(index3,"ppp.json");


                //function
                function csvtojson(index,filename){
                var i=0,j=0;
                jArray1=[];
                for (i = 1; i < noOfRow-1; i++) {
                   var obj1 = {};
                   var myNewLine=arrayOne[i].split(',');
                   for (j = 0; j< col; j++) {

                     var headerText = header[0];
                     var valueText = myNewLine[0];
                     headerText1 = header[index];
                     var valueText1 = myNewLine[index];
                     obj1[headerText] = valueText;
                     obj1[headerText1] = valueText1;
                   };
                     jArray1.push(obj1);

              };
              jArray1.sort(function(a,b){
               return parseFloat(b[headerText1])-parseFloat(a[headerText1]);
              })

              console.log( jArray1);

              fs.writeFile( filename, JSON.stringify( jArray1 ), "utf8", (err) => {
              if (err) throw err;
              console.log('Saved as cgp_JSON!');
              });

              }
}
